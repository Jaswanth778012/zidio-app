import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../_services/admin.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-course-management',
  templateUrl: './course-management.component.html',
  styleUrl: './course-management.component.css'
})
export class CourseManagementComponent implements OnInit {
  courses: any[] = [];
  categories: any[] = [];
  reviews: any[] = [];
  auditLogs: any[] = [];
  filterForm!: FormGroup;
  newCourseName: string = '';
  editCourse: any = null;
  selectedCourseId: number | null = null;
  updatedCourseName = '';
  assignUserName = '';
  adminuserName = 'admin123'; // This should be fetched from the auth service
  selectedCategory: any = { name: '' };
  flaggedReviews: any[] = [];
  selectedCourseReviews: any[] = [];
  searchTerm: string = '';
filteredCourses: any[] = [];
selectedCategoryId: number = 1;
courseForm!: FormGroup;
  constructor(private adminService: AdminService, private snackBar: MatSnackBar,private fb: FormBuilder) {}

  ngOnInit(): void {
    this.loadCourses();
    this.loadCategories();
    this.loadFlaggedReviews();
    this.filterForm = this.fb.group({
      categoryId: [''],
      status: [''],
      active: ['']
    });
    this.courseForm = this.fb.group({
    courseName: ['', Validators.required],
    description: ['', Validators.required],
    tags: [[]],
    contentType: ['video'],
    previewUrl: [''],
    prerequisites: [[]],
    certificate: [false],
    selfPaced: [false],
    startDate: [''],
    endDate: [''],
    creatorUsername: [''],
    categoryId: [1, Validators.required]
    // Add other controls as needed
  });
  }

  loadCourses() {
  this.adminService.getAllCourses().subscribe({
    next: (res) => {
      console.log('Courses loaded:', res); // 🔍 Debug this
      this.courses = res;
      this.filteredCourses = res;
    },
    error: (err) => {
      console.error('Error loading courses:', err);
    }
  });
}

  loadCategories(): void {
    this.adminService.getAllCategories().subscribe(data => {this.categories = data
      if (data.length > 0 && !this.courseForm.get('categoryId')?.value) {
  this.courseForm.patchValue({ categoryId: data[0].id });
}
    });
  }

  addCourse() {
 if (this.courseForm.invalid) {
  this.snackBar.open('❌ Please fill all required fields', 'Close', { duration: 3000 });
  return;
}

  const payload = {
  courseName: this.courseForm.value.courseName,
  description: this.courseForm.value.description,
  tags: this.courseForm.value.tags || [],
  contentType: this.courseForm.value.contentType || "video",
  previewUrl: this.courseForm.value.previewUrl || "",
  prerequisites: this.courseForm.value.prerequisites || [],
  certificate: this.courseForm.value.certificate || false,
  selfPaced: this.courseForm.value.selfPaced || false,
  startDate: this.courseForm.value.startDate || null,
  endDate: this.courseForm.value.endDate || null,
  creatorUsername: this.adminuserName, // should be fetched or passed
  categoryId: this.courseForm.value.categoryId
};


  console.log("Course Payload:", payload); // 🐞 Log for debugging

  this.adminService.addCourse(payload).subscribe({
    next: () => {
      this.snackBar.open('✅ Course added', 'Close', { duration: 3000 });
      this.newCourseName = '';
      this.loadCourses();
    },
    error: (err) => {
      console.error('Error adding course:', err); // Detailed error
    }
  });
}

 startEdit(course: any): void {
    this.editCourse = { ...course };
  }
loadFlaggedReviews(): void {
    this.adminService.getFlaggedReviews().subscribe(data => this.flaggedReviews = data);
  }


  updateCourse(courseId: number) {
  if (!this.updatedCourseName.trim()) return;

  const updateRequest = {
    courseName: this.updatedCourseName,
    description: this.editCourse?.description|| '', // Optional: use field
    categoryId: this.editCourse?.categoryId,                     // Optional: use form
    certificateLink: '',
    active: true
  };

  this.adminService.updateCourse(courseId, updateRequest).subscribe({
    next: () => {
      this.snackBar.open('✏️ Course updated', 'Close', { duration: 3000 });
      this.updatedCourseName = '';
      this.selectedCourseId = null;
      this.loadCourses();
    },
    error: () => {
      this.snackBar.open('❌ Failed to update course', 'Close', { duration: 3000 });
    }
  });
}

  deleteCourse(courseId: number) {
    this.adminService.deleteCourse(courseId).subscribe({
      next: () => {
        this.snackBar.open('🗑️ Course deleted', 'Close', { duration: 3000 });
        this.loadCourses();
      }
    });
  }
    archiveCourse(CourseId: number): void {
    this.adminService.archiveCourse(CourseId).subscribe(() => this.loadCourses());
  }

  toggleVisibility(id: number, active: boolean): void {
    this.adminService.toggleCourseVisibility(id, !active).subscribe(() => this.loadCourses());
  }

  changeStatus(id: number, status: string): void {
    this.adminService.updateCourseStatus(id, status).subscribe(() => this.loadCourses());
  }


  assignFaculty(courseId: number) {
    if (!this.assignUserName.trim()) return;
    this.adminService.assignFaculty(courseId, this.assignUserName).subscribe({
      next: () => {
        this.snackBar.open('👨‍🏫 Faculty assigned', 'Close', { duration: 3000 });
        this.assignUserName = '';
        this.loadCourses();
      }
    });
  }

  filterCourses(): void {
    const params = this.filterForm.value;
    this.adminService.filterCourses(params).subscribe(data => {
  this.courses = data;
  this.filteredCourses = data;
});
  }

  getAuditLogs(courseId: number): void {
    this.selectedCourseId = courseId;
    this.adminService.getCourseAuditLogs(courseId).subscribe(logs => this.auditLogs = logs);
  }

  getCourseReviews(courseId: number): void {
     this.selectedCourseId = courseId;
    this.adminService.getCourseReviews(courseId).subscribe(reviews => this.selectedCourseReviews = reviews);
  }

  deleteReview(id: number): void {
   
    this.adminService.deleteReview(id).subscribe(() => this.loadFlaggedReviews());
  }

flagReview(id: number): void {
    this.adminService.flagReview(id).subscribe(() => {
      this.loadFlaggedReviews();
      if (this.selectedCourseId) this.getCourseReviews(this.selectedCourseId);
    });
  }

  // Category management
  createCategory(): void {
    this.adminService.createCategory(this.selectedCategory).subscribe(() => {
      this.loadCategories();
      this.selectedCategory = { name: '' };
    });
  }

  updateCategory(category: any): void {
    this.adminService.updateCategory(category.id, category).subscribe(() => this.loadCategories());
  }

  deleteCategory(id: number): void {
    this.adminService.deleteCategory(id).subscribe(() => this.loadCategories());
  }

  onSearchChange(): void {
  const term = this.searchTerm.toLowerCase();
  this.filteredCourses = this.courses.filter(course =>
    course.name.toLowerCase().includes(term)
  );
}
}


package com.spring.zidio.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.zidio.Job;
import com.spring.zidio.PostStatus;

public interface JobDao extends JpaRepository<Job, Long> {
	// Custom query methods can be defined here if needed
	List<Job> findByStatus(PostStatus status);
	long countByStatus(PostStatus status);


}

package com.spring.zidio.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.zidio.Internship;
import com.spring.zidio.PostStatus;
import com.spring.zidio.dao.InternshipDao;

@Service
public class InternshipService {

    @Autowired
    private InternshipDao internshipDao;

    public List<Internship> getAllInternships() {
        return internshipDao.findAll();
    }

    public List<Internship> getFlaggedInternships() {
        return internshipDao.findByStatus(PostStatus.FLAGGED);
    }
    
    public Internship updateInternshipStatus(Long id, String status) {
        Internship internship = internshipDao.findById(id)
        		.orElseThrow(() -> new RuntimeException("Job not found"));
        try {
            // ✅ Convert string to enum safely
            PostStatus parsedStatus = PostStatus.valueOf(status.toUpperCase());
            internship.setStatus(parsedStatus);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Invalid status. Use APPROVED, REJECTED, FLAGGED, or PENDING.");
        }
        return internshipDao.save(internship);
    }

    public void deleteInternship(Long id) {
        internshipDao.deleteById(id);
    }
}
package com.spring.zidio.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.zidio.Internship;
import com.spring.zidio.PostStatus;

public interface InternshipDao extends JpaRepository<Internship, Long> {
	 List<Internship> findByStatus(PostStatus status);
	 long countByStatus(PostStatus status);

}

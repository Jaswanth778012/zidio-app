package com.spring.zidio;

public enum UserStatus {
	PENDING, APPROVED, BLOCKED
}

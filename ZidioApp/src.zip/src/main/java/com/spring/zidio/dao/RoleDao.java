package com.spring.zidio.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.zidio.Role;

public interface RoleDao extends JpaRepository<Role, String> {
	// Custom query methods can be defined here if needed

}

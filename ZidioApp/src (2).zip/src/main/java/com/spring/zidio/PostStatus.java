package com.spring.zidio;

public enum PostStatus {
	
	PENDING,
    APPROVED,
    REJECTED,
    FLAGGED
}

package com.spring.zidio.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.zidio.Job;
import com.spring.zidio.PostStatus;
import com.spring.zidio.dao.JobDao;

@Service
public class JobService {

    @Autowired
    private JobDao jobDao;

    public List<Job> getAllJobs() {
        return jobDao.findAll();
    }

    public List<Job> getFlaggedJobs() {
        return jobDao.findByStatus(PostStatus.FLAGGED);
    }
    
    public Job updateJobStatus(Long id, String status) {
        Job job = jobDao.findById(id)
            .orElseThrow(() -> new RuntimeException("Job not found"));

        try {
            // ✅ Convert string to enum safely
            PostStatus parsedStatus = PostStatus.valueOf(status.toUpperCase());
            job.setStatus(parsedStatus);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Invalid status. Use APPROVED, REJECTED, FLAGGED, or PENDING.");
        }

        return jobDao.save(job);
    }

    public void deleteJob(Long id) {
        jobDao.deleteById(id);
    }
}
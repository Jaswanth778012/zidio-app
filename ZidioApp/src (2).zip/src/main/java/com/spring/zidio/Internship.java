package com.spring.zidio;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Internship {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    private String description;

    private String duration;  // ✅ New Field (e.g. "3 months")

    private boolean flagged = false;
    
    @Enumerated(EnumType.STRING)
    private PostStatus status = PostStatus.PENDING;


    @ManyToOne
    @JoinColumn(name = "employer_username")
    private User postedBy;
}
